
import './App.css';
import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { withRouter } from 'react-router';
import { Navbar,Nav,Button } from 'react-bootstrap';

import { BrowserRouter as Router, Link, Switch, Route, Redirect } from 'react-router-dom';
import NavHome from './NavHome';

import UserLogin from './UserLogin';



function App (props){
   return(
       <Fragment>
         
         <NavHome />


    

       </Fragment>

   )
}


export default App;
