import React, { Fragment,useState , useEffect} from 'react';
import { Navbar, Button, Card, Form, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import './App.css';

function UserLogin(props) {
    
    useEffect(() => {
        loadUsers();
    }, []);
    const[username,setUsername]=useState('');
    const[password,setPassword]=useState('');
 
    const usernameinputvalchange = (e) => {
 
        setUsername(e.target.value);
 
    }
    const passwordinputvalchange = (e) => {
        setPassword(e.target.value);
 
    }
    const [users, setUser] = useState([]);
    const loadUsers = async () => {
        await axios.get('http://localhost:3003/users')
            .then(response => {
               setUser(response.data);
            });
    }
 
    const onSubmit = () => {
 
        
        const isUsernameValid = username
    
    
        if (isUsernameValid) {
            for(let i=0; i< users.length; i++){

                if(username == users[i].email && password == users[i].password && users[i].role == 'Admin'){
                    return props.history.push('/adminaxios');
                }else if(username == users[i].email && password == users[i].password && users[i].role == 'User') {
                    sessionStorage.setItem("user" , JSON.stringify(users[i]));
                    return props.history.push('/useraxios');
                   
                }else{
                   if(i == users.length -1){
                    alert("User name and password not matched");
                   }
                }
            }
        } 
        else {
            alert("Invalid Credentials");
        }
 
    }
    return (
        <div className="body" style={{ 

            backgroundImage: `url("https://th.bing.com/th/id/Rcb3ea77bc303d8e379aca0c0916cafac?rik=Y6DYZIYKjjA3ag&riu=http%3a%2f%2fgetwallpapers.com%2fwallpaper%2ffull%2fa%2f9%2f2%2f29702.jpg&ehk=XzBkKN86zXbM%2fLyfdNITGljJEUEH%2blam0UL%2btdeZRA8%3d&risl=&pid=ImgRaw")`,backgroundRepeat: 'no-repeat',width:'1300px',height:'550px',color:'black' 
           
            }} >
                
           

                
                    <Card className="UserCard" style={{ width: '15rem', backgroundImage: `url("https://th.bing.com/th/id/R220568ed4e83c98f2a390a0e3d92efb3?rik=oUH7iR2Sjoa5rA&riu=http%3a%2f%2fwww.pixelstalk.net%2fwp-content%2fuploads%2f2016%2f09%2fDownload-All-White-Image.jpg&ehk=%2bQMyqpj8O008ybzZBs7Srk7JArJjRjwys58Cm%2ftvHZk%3d&risl=&pid=ImgRaw")`,backgroundRepeat: 'no-repeat',width:'250px',height:'300px',color:'black' }}>
                    <Card.Body>
                    <Card.Title className="UserTitle">Login</Card.Title><br />
                    <Form>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label style={{ marginRight: "120px" }}>User ID</Form.Label>
                            <Form.Control type="email" placeholder="Enter Username" onChange={usernameinputvalchange}/>

                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label style={{ marginRight: "270px" }}>Password</Form.Label>
                            <Form.Control type="password" placeholder="Enter Password" onChange={passwordinputvalchange}/>
                        </Form.Group>

                        <Button variant="dark"  block onClick={onSubmit}>Submit</Button>
                    </Form>
                </Card.Body>


                    </Card>

                  

               

            



        </div>
    )
}
export default UserLogin;