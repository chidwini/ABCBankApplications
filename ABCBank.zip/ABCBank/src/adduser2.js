import React, { Fragment, useState } from 'react';
import { Container, Card, Form,Button } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';
import Adminaxios from './adminaxios';
import axios from 'axios';


const Adduser2 = () => {


    const [user, setUser] = useState({
        firstName: '',
        lastName: '',
        email: ' ',
        phone: ' ',
        
        AdharNO: null,
        balance: 0,
        password:'',
        currentBalence:0,
        transaction:[],
        role:''
        

    });

    const history = useHistory();

    const { firstName, lastName, email, phone, AdharNO,balance,currentBalence,password,transaction,role } = user;

    const onInputChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value })
        console.log(e.target.value);
    }

    const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:3003/users", user);
        history.push("/adminaxios")

    }
    return (
        <Fragment>
            
           
                <Card  className="addusercard">
                <Card.Title className="t1"><h2><small>Add User</small></h2></Card.Title><br></br>
                    <Form onSubmit={e => onSubmit(e)}>
                     
                        <Form.Group controlId="formBasicAdhar">
                            <Form.Label>Adhar Number</Form.Label>
                            <Form.Control type="number" placeholder="AdharNumber" name='AdharNO' value={AdharNO} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="password" name='password' value={password} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Role</Form.Label>
                            <Form.Control type="text" placeholder="role" name='role' value={role} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        
                        <Button variant="primary" type="submit" block> Submit </Button>
                    </Form>

                </Card>

            
        </Fragment>
    )
}
export default Adduser2;


