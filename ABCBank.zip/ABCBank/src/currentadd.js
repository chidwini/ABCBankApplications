import React, { Fragment, useState, useEffect } from 'react';
import { Navbar, Button, Card, Form, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';


function CurrentBalence() {
    const [user, setUser] = useState({
        id: '',
        firstName: ' ',
        lastName: ' ',
        email: ' ',
        phone: ' ',
        website: ' ',
        currentBalence:0,
        transaction: []

    });
    const [amount, setAmount] = useState('');

    const { id } = useParams();
    useEffect(() => {
        const res = sessionStorage.getItem('user');
        let user = JSON.parse(res);
        getUser(user.id);
    }, []);

    const getUser = async (id) => {
        const res = await axios.get(`http://localhost:3003/users/${id}`);
        setUser(res.data);
    }

    const onSubmit = async e => {
        e.preventDefault();
        let date = new Date;
        let obj= {
            "type": '',
            "accountType": '',
            "dateTime": date,
            "amount":0
        };
        obj.amount = amount;
        if(parseInt(amount) > 0){
            obj.type = "Credit";
        }else {
            obj.type = "Debit";
        }
        obj.accountType = "Current";
        user.transaction.push(obj);
        user.currentBalence = parseInt(user.currentBalence) + parseInt(amount);
        await axios.put(`http://localhost:3003/users/${user.id}`, user);
        getUser(user.id);
        alert('Amount added successfully');

    }
    const onSubmitWithDraw = async e => {
        e.preventDefault();
        let date = new Date;
        let obj= {
            "type": '',
            "accountType": '',
            "dateTime": date,
            "amount":0
        };
        obj.amount = amount;
        if(parseInt(amount) < 0){
            obj.type = "Credit";
        }else {
            obj.type = "Debit";
        }
        obj.accountType = "Current";
        user.transaction.push(obj);
        user.currentBalence = parseInt(user.currentBalence) - parseInt(amount);
        await axios.put(`http://localhost:3003/users/${user.id}`, user);
        getUser(user.id);
        alert('with Draw Amount successfully');

    }
    const passwordinputvalchange = (e) => {
        setAmount(e.target.value);

    }
    return (
        <div style={{

            backgroundImage: `url("https://th.bing.com/th/id/Rcb3ea77bc303d8e379aca0c0916cafac?rik=Y6DYZIYKjjA3ag&riu=http%3a%2f%2fgetwallpapers.com%2fwallpaper%2ffull%2fa%2f9%2f2%2f29702.jpg&ehk=XzBkKN86zXbM%2fLyfdNITGljJEUEH%2blam0UL%2btdeZRA8%3d&risl=&pid=ImgRaw")`, width: '1300px', height: '800px', color: 'black'

        }}>
            <Link class='btn btn-outline-primary btnAdd' to={'/useraxios'} block >Back</Link>

            <Row>
                <Col >
                <Card className="addAmountCard">
                <Card.Title className="UserTitle">Add Amount</Card.Title><br />
                    <Form>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label ><b>User Name:</b> {user.firstName}{' '}{user.lastName}</Form.Label>
                            {/* <Form.Control type="email" placeholder="Enter Username" /> */}

                        </Form.Group>
                        <Form.Group controlId="formBasicEBal">
                            <Form.Label ><b>Current Balence:</b> {user.currentBalence}</Form.Label>
                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label style={{ marginRight: "270px" }}>Amount</Form.Label>
                            <Form.Control type="number" placeholder="Amount" onChange={passwordinputvalchange} />
                        </Form.Group>

                        <Button class="btn btn-outline-primary" variant="dark" onClick={onSubmit} block >Submit</Button>
                    </Form>
                </Card>
                </Col>
                <Col>
                <Card className="addAmountCard">
                <Card.Title className="UserTitle">With Draw Amount</Card.Title><br />
                    <Form>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label ><b>User Name:</b> {user.firstName}{' '}{user.lastName}</Form.Label>
                            {/* <Form.Control type="email" placeholder="Enter Username" /> */}

                        </Form.Group>
                        <Form.Group controlId="formBasicEBal">
                            <Form.Label ><b>Saving Balance:</b> {user.currentBalence}</Form.Label>
                        </Form.Group>

                        <Form.Group controlId="formBasicPassword">
                            <Form.Label style={{ marginRight: "270px" }}>Amount</Form.Label>
                            <Form.Control type="number" placeholder="Amount" onChange={passwordinputvalchange} />
                        </Form.Group>

                        <Button class="btn btn-outline-primary" variant="dark" onClick={onSubmitWithDraw} block >Submit</Button>
                    </Form>
                </Card>
                </Col>
            </Row>
            

               
            
        </div>
    )
}


export default CurrentBalence;