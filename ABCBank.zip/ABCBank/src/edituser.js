import React, { Fragment, useState ,useEffect} from 'react';
import { Container, Card,Form,Button } from 'react-bootstrap';
import {useHistory,useParams, Link} from 'react-router-dom';
import Adminaxios from './adminaxios';
import axios from 'axios';

const Edituser =()=>{

    const [user, setUser] = useState({
        firstName: '',
        lastName: '',
        email: ' ',
        phone: ' ',
        Branch:'',
        AdharNO: null,
        balance: 0,
        password:'',
        currentBalence:0,
        transaction:[],
        role:''

    });

    const history=useHistory();
    const {id}=useParams();

    const { firstName, lastName, email,Branch, phone, AdharNO,balance,currentBalence,password,transaction,role } = user;

    const onInputChange= e =>
    {
        setUser({...user,[e.target.name] : e.target.value})
        console.log(e.target.value);
    }
    useEffect(() =>{
        loadUser();

    },[]);

    const onSubmit= async e =>{
        e.preventDefault();
        await axios.put(`http://localhost:3003/users/${id}`,user);
        history.push("/adminaxios");

    }

    const loadUser= async() =>{
        const result=await axios.get(`http://localhost:3003/users/${id}`);
       setUser(result.data);
    }
    return (
        <div className="editClass">
             <Link class='btn btn-outline-primary' to={'/adminaxios'} >Back </Link>{' '}
            
            
            <Card className="addusercard" style={{ width: '20rem', backgroundImage: `url("https://th.bing.com/th/id/R220568ed4e83c98f2a390a0e3d92efb3?rik=oUH7iR2Sjoa5rA&riu=http%3a%2f%2fwww.pixelstalk.net%2fwp-content%2fuploads%2f2016%2f09%2fDownload-All-White-Image.jpg&ehk=%2bQMyqpj8O008ybzZBs7Srk7JArJjRjwys58Cm%2ftvHZk%3d&risl=&pid=ImgRaw")`,backgroundRepeat: 'no-repeat' }}>
            <Card.Title className="t1"><h2><small>Edit User</small></h2></Card.Title><br></br>
            <Form onSubmit={e => onSubmit(e)}>
            
                        <Form.Group controlId="formBasicNmae">
                            <Form.Label>First Name</Form.Label>
                            <Form.Control type="text" placeholder="firstName" name='firstName' value={firstName} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>

                        <Form.Group controlId="formBasicUsername">
                            <Form.Label>Last Name</Form.Label>
                            <Form.Control type="text" placeholder="lastName" name='lastName' value={lastName} onChange={e => onInputChange(e)}/>
                        </Form.Group>
                        <Form.Group controlId="formBasicEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control type="email" placeholder="Email" name='email' value={email} onChange={e => onInputChange(e)}/>

                            
                        </Form.Group>
                        <Form.Group controlId="formBasicMobile">
                            <Form.Label>MobileNumber</Form.Label>
                            <Form.Control type="number" placeholder="Mobile Number" name='phone' value={phone} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicAdhar">
                            <Form.Label>Adhar Number</Form.Label>
                            <Form.Control type="number" placeholder="AdharNumber" name='AdharNO' value={AdharNO} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Branch</Form.Label>
                            <Form.Control type="text" placeholder="Branch" name='Branch' value={Branch} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="password" name='password' value={password} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        <Form.Group controlId="formBasicPassword">
                            <Form.Label>Role</Form.Label>
                            <Form.Control type="text" placeholder="role" name='role' value={role} onChange={e => onInputChange(e)}/>
                            
                        </Form.Group>
                        
                        <Button variant="dark" onSubmit={e => onSubmit(e)} type="submit" block> Submit </Button>
                    </Form>

            </Card>

            
           
        </div>
    )
}

export default Edituser;