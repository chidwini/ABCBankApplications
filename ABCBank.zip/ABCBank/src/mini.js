import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Button, Card, Table } from 'react-bootstrap';

function MiniStatement() {

    const [user, setUser] = useState({

        lastName: ' ',
        balance: ' ',
        transaction: []

    });
    const from = sessionStorage.getItem('from');
    const { id } = useParams();

    useEffect(() => {
        loadUser();
    }, []);

    const loadUser = async () => {
        const res = await axios.get(`http://localhost:3003/users/${id}`);
        setUser(res.data);
    }
    return (
        <div className="miniClass">
             <Link class='btn btn-outline-primary btnAdd' to={'/useraxios'} block >Back </Link>
            <Card className="miniCard" >
            <Card.Title className="UserTitle">Mini Statement</Card.Title><br />
                <p><b>Account HolderName:</b> {user.lastName}</p>
                {from === 'Current' ? <p><b>Account Balance:</b> {user.currentBalence}</p>: <p>Account Balance: {user.balance}</p>   }
                

                <Table striped bordered hover variant="dark">
                    <thead>
                        <tr>
                            
                            <th>Transaction Type</th>
                            <th>Amount</th>
                            <th>AccountType</th>
                            <th>Date&Time</th>
                        </tr>
                    </thead>
                    <tbody>

                        {
                            user.transaction.map(tran => tran.accountType === from ?  (
                                <tr>
                                    <td>{tran.type}</td>
                                    <td>{tran.amount}</td>
                                    <td>{tran.accountType}</td>
                                    <td>{tran.dateTime}</td>
                                </tr>
                            ) :  (<tr>
                                
                            </tr>)
                             ) }
                    </tbody>
                </Table>
               
            </Card>

        </div>
    )

}
export default MiniStatement;