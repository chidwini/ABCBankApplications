import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Button, Alert, Row, Col, Card, Jumbotron } from 'react-bootstrap';

const Viewuser = (props) => {

    const [user, setUser] = useState({
        firstName: ' ',
        lastName: ' ',
        email: ' ',
        phone: ' ',
        Branch: '',
        AdharNO: ' ',
        balance: '0',
        cType: ' ',
        sType: ' ',
        currentBalence: '0',

    });
    const [showButton, setShowBotton] = useState(null);

    const { id } = useParams();
    useEffect(() => {
        loadUser();
    }, []);

    const loadUser = async () => {
        const res = await axios.get(`http://localhost:3003/users/${id}`);
        setUser(res.data);
    }
    const userButton = () => {
        props.history.push('/addamount');
    }
    const currentAddAmount = () => {
        props.history.push('/currentadd');
    }
    const currentButton = () => {
        setShowBotton(!true);
    }
    const savingsButton = () => {
        setShowBotton(true);
    }
    const setData = (falg) => {
        sessionStorage.setItem('from', falg)
    }
    return (
        <center>


            <div className="body" 
            style={{

                backgroundImage: `url("https://th.bing.com/th/id/Rcb3ea77bc303d8e379aca0c0916cafac?rik=Y6DYZIYKjjA3ag&riu=http%3a%2f%2fgetwallpapers.com%2fwallpaper%2ffull%2fa%2f9%2f2%2f29702.jpg&ehk=XzBkKN86zXbM%2fLyfdNITGljJEUEH%2blam0UL%2btdeZRA8%3d&risl=&pid=ImgRaw")`, width: '1300px', height: '800px', color: 'white'

            }}
             >

                <p className="display-4"> Account Number:{id}</p>


                <hr />
                <Row>
                    <Col className="currentImage">
                        <Card className="gallery" style={{ width: '15rem' }}>

                            <Card.Img variant="top" src="https://www.cnsbank.co.in/images/c-account.jpg" />
                            <Button variant="dark" onClick={currentButton}>Current</Button>{' '}
                        </Card>
                    </Col>
                    <Col className="savingImage">
                        <Card style={{ width: '14rem' }}>
                            <Card.Img variant="top" src="https://www.jagoinvestor.com/wp-content/uploads/files/Basic-savings-bank-account.png" />
                            <Button variant="dark" onClick={savingsButton}>savings</Button>
                        </Card>
                    </Col>
                </Row>


                {
                    showButton === true && (<div>
                        <Row style={{ color: "black" }}>

                            <Col className="savingList" sm={8}>

                                <ul className="list-group w-50">
                                    <li className="list-group-item">FirstName : {user.firstName}</li>
                                    <li className="list-group-item">LastName : {user.lastName}</li>
                                    <li className="list-group-item">Email: {user.email}</li>
                                    <li className="list-group-item">Mobile : {user.phone}</li>
                                    <li className="list-group-item">Branch : {user.Branch}</li>
                                    <li className="list-group-item"> AdharNO: {user.AdharNO}</li>
                                    <li className="list-group-item">Balance : {user.balance}</li>
                                    <li className="list-group-item">Account Type : Savings Account</li>
                                </ul>

                            </Col>
                            <Col className="viewButtuon">
                                <Link class='btn btn-outline-primary' to={`/addamount/${user.id}`}>Fund Transfer</Link><br /><br />
                                <Link class='btn btn-outline-primary' onClick={setData('Savings')} to={`/mini/${user.id}`}>MiniStatement</Link>
                                </Col>
                        </Row>
                        {/* <button class="btn btn-outline-primary btnAdd" onClick={userButton} >Add Amount</button> */}


                    </div>


                    )}{(showButton === false &&
                        <div>
                            <Row style={{ color: "black" }}>


                                <Col className="savingList" sm={8} >

                                    <ul className="list-group w-50">
                                        <li className="list-group-item">FirstName: {user.firstName}</li>
                                        <li className="list-group-item">LastName : {user.lastName}</li>
                                        <li className="list-group-item">Email: {user.email}</li>
                                        <li className="list-group-item">Mobile : {user.phone}</li>
                                        <li className="list-group-item">Branch: {user.Branch}</li>
                                        <li className="list-group-item"> AdharNO: {user.AdharNO}</li>
                                        <li className="list-group-item">Balance : {user.currentBalence}</li>
                                        <li className="list-group-item">Account Type: Current Account</li>
                                    </ul>
                                </Col>
                                <Col className="viewButtuon">
                                    <Link class='btn btn-outline-primary' onClick={currentAddAmount}>Fund Transfer</Link><br /><br />
                                    <Link class='btn btn-outline-primary' onClick={setData('Current')} to={`/mini/${user.id}`}>MiniStatement</Link>
                                </Col>
                            </Row>
                        </div>


                    )}



            </div>



        </center>
    )
}

export default Viewuser;